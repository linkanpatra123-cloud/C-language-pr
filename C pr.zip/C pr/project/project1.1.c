#include<stdio.h>

int main()
{
	float c=0,f=0;
	
	printf("Enter c=> ");
	scanf("%f",&c);
	
	f=((9*c)/5)+32;
	
	printf("F => %f",f);
	
}

//output

//Enter c=> 38
//F => 100.400002